import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
/**
* Servlet implementation class Register
*/
@WebServlet("/booking")
public class booking extends HttpServlet {
private static final long serialVersionUID = 1L;

Connection conn=null;
String url="jdbc:mysql://192.168.25.119:3306/";
String dbName="sample?useSSL=false";
String driver="com.mysql.jdbc.Driver";
String dbUserName="neha";
String dbPassword="Neha@123";

/**
 * @see HttpServlet#HttpServlet()
 */
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    
	
    // Set response content type
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    try {
       // Register JDBC driver
       Class.forName("com.mysql.jdbc.Driver");

       // Open a connection
   Connection conn = DriverManager.getConnection(url+dbName,dbUserName, dbPassword);
  
      
       
       // Execute SQL query
       Statement stmt = conn.createStatement();
       String sql;
       sql = "select * from Booking";
       ResultSet rs = stmt.executeQuery(sql);

       // Extract data from result set
       while(rs.next()){
          //Retrieve by column name
    	   String name = rs.getString("name");    	
    	   String contact = rs.getString("contact");
    	   String mail_id = rs.getString("mail_id");
    	   String hall = rs.getString("hall_name");
    	   String capacity = rs.getString("Sitting_Capacity");  
           String projector = rs.getString("projector");    	   
    	   String purpose = rs.getString("purpose");
    	   String date= rs.getString("date");
    	   String start = rs.getString("start");
    	   String end = rs.getString("end");
    	   
    	   int rowCount = 0;
    	   
    	   out.println("<P ALIGN='center'><TABLE BORDER=1 CELLPADDING=0 CELLSPACING=0 WIDTH=70%>");
    	 
     	  ResultSetMetaData rsmd = rs.getMetaData();
     	  int columnCount = rsmd.getColumnCount();
     	  // table header
     	  out.println("<TR>");
     	  for (int i = 0; i < columnCount; i++) {
     	    out.println("<TH>" + rsmd.getColumnLabel(i + 1) + "</TH>");
     	    }
     	  out.println("</TR>");
     	  // the data
     	  while (rs.next()) {
     	   rowCount++;
     	   out.println("<TR>");
     	   for (int i = 0; i < columnCount; i++) {
     	     out.println("<TD>" + rs.getString(i + 1) + "</TD>");
     	     }
     	   out.println("</TR>");
     	   }
     	  out.println("</TABLE></P>");

       }
	
       
      
       // Clean-up environment
       rs.close();
       stmt.close();
       conn.close();
    } catch(SQLException se) {
       //Handle errors for JDBC
       se.printStackTrace();
    } catch(Exception e) {
       //Handle errors for Class.forName
       e.printStackTrace();
    } finally {
       //finally block used to close resources
      
       try {
          if(conn!=null)
          conn.close();
       } catch(SQLException se) {
          se.printStackTrace();
       } //end finally try
    } //end finally


    
    }
	          

/**
 * @param <SimpleDateFormat>
 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
    	
    	response.setContentType("text/html");  
    	PrintWriter pw = response.getWriter(); 
        try{  
        	String name = request.getParameter("name");  
            String contact = request.getParameter("contact"); 
            String mail_id = request.getParameter("mail_id");
            String hall = request.getParameter("hall_name");
            String capacity = request.getParameter("Sitting_Capacity");  
            boolean projector= Boolean.parseBoolean(request.getParameter("projector")); 
            String purpose = request.getParameter("purpose");  
            String dat = request.getParameter("date");  
        
            //Date Converter code
		            Date date1 = new Date();
		        	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		        
		            formatter = new SimpleDateFormat("yyyy-MM-dd");
		        	String strDate = formatter.format(date1);
		            System.out.println("=============="+strDate);
            //End of date converter

            String start = request.getParameter("start");  
            String end = request.getParameter("end");           
          

          Class.forName(driver).newInstance();  
         conn = DriverManager.getConnection(url+dbName,dbUserName, dbPassword);
    
          
        PreparedStatement pst =(PreparedStatement) conn.prepareStatement("insert into Booking(name,contact,mail_id,hall_name,Sitting_Capacity,projector,purpose,date,start,end) values(?,?,?,?,?,?,?,?,?,?)");
      
          pst.setString(1,name);
          pst.setString(2,contact);
          pst.setString(3,mail_id);
          pst.setString(4,hall);
          pst.setString(5,capacity); 
          pst.setBoolean(6,projector);
          pst.setString(7,purpose);        
          pst.setString(8,strDate);
          pst.setString(9,start);
          pst.setString(10,end);
          

          int i = pst.executeUpdate();
         
          String msg=" ";
          if(i!=0){  
            msg="Record has been inserted";
            pw.println("<font size='6' color=blue>" + msg + "</font>");  


          }  
          else{  
            msg="failed to insert the data";
            pw.println("<font size='6' color=blue>" + msg + "</font>");
           }  
          pst.close();
        }  
        catch (Exception e){  
          pw.println(e);  
        }  

    }
}