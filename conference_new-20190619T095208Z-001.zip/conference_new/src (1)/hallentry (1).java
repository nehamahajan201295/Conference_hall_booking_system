import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
* Servlet implementation class Register
*/
@WebServlet("/hallentry")
public class hallentry extends HttpServlet {
private static final long serialVersionUID = 1L;

Connection conn=null;
String url="jdbc:mysql://192.168.25.119:3306/";
String dbName="sample?useSSL=false";
String driver="com.mysql.jdbc.Driver";
String dbUserName="neha";
String dbPassword="Neha@123";

/**
 * @see HttpServlet#HttpServlet()
 */
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    
	
    // Set response content type
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    try {
       // Register JDBC driver
       Class.forName("com.mysql.jdbc.Driver");

       // Open a connection
   Connection conn = DriverManager.getConnection(url+dbName,dbUserName, dbPassword);
  
      
       
       // Execute SQL query
       Statement stmt = conn.createStatement();
       String sql;
       sql = "select * from Hall";
       ResultSet rs = stmt.executeQuery(sql);

       // Extract data from result set
       while(rs.next()){
          //Retrieve by column name
    	   String h_id = rs.getString("H_id"); 
    	   String name = rs.getString("Hall_name");    	
    	   String contact = rs.getString("Sitting_Capacity");
    	   String projector = rs.getString("projector");
    	   
    	   int rowCount = 0;
    	   
    	   out.println("<P ALIGN='center'><TABLE BORDER=1 CELLPADDING=0 CELLSPACING=0 WIDTH=30%>");
    	 
     	  ResultSetMetaData rsmd = rs.getMetaData();
     	  int columnCount = rsmd.getColumnCount();
     	  // table header
     	  out.println("<TR>");
     	  for (int i = 0; i < columnCount; i++) {
     	    out.println("<TH>" + rsmd.getColumnLabel(i + 1) + "</TH>");
     	    }
     	  out.println("</TR>");
     	  // the data
     	  while (rs.next()) {
     	   rowCount++;
     	   out.println("<TR>");
     	   for (int i = 0; i < columnCount; i++) {
     	     out.println("<TD>" + rs.getString(i + 1) + "</TD>");
     	     }
     	   out.println("</TR>");
     	   }
     	  out.println("</TABLE></P>");

       }
	
       
      
       // Clean-up environment
       rs.close();
       stmt.close();
       conn.close();
    } catch(SQLException se) {
       //Handle errors for JDBC
       se.printStackTrace();
    } catch(Exception e) {
       //Handle errors for Class.forName
       e.printStackTrace();
    } finally {
       //finally block used to close resources
      
       try {
          if(conn!=null)
          conn.close();
       } catch(SQLException se) {
          se.printStackTrace();
       } //end finally try
    } //end finally


    
    }
	          

/**
 * @param <SimpleDateFormat>
 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub


    	response.setContentType("text/html");  
    	PrintWriter pw = response.getWriter(); 
        try{  
        	String H_id = request.getParameter("H_id");  
        	String hall_name = request.getParameter("Hall_name");  
            String sitting_capacity = request.getParameter("Sitting_Capacity"); 
            boolean projector= Boolean.parseBoolean(request.getParameter("projector"));
        

          Class.forName(driver).newInstance();  
         conn = DriverManager.getConnection(url+dbName,dbUserName, dbPassword);
    
          
       PreparedStatement pst =(PreparedStatement) conn.prepareStatement("insert into Hall(Hall_name,Sitting_Capacity,projector) values(?,?,?)");
      
         
          pst.setString(1,hall_name);
          pst.setString(2,sitting_capacity);
          pst.setBoolean(3,projector);
          
          int i = pst.executeUpdate();
         
          String msg=" ";
          if(i!=0){  
            msg="Record has been inserted";
            pw.println("<font size='6' color=blue>" + msg + "</font>");  


          }  
          else{  
            msg="failed to insert the data";
            pw.println("<font size='6' color=blue>" + msg + "</font>");
           }  
          pst.close();
        }  
        catch (Exception e){  
          pw.println(e);  
        }  

    }
}