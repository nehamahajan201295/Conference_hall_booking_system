import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
* Servlet implementation class Register
*/
@WebServlet("/hall_update")
public class hall_update extends HttpServlet {
private static final long serialVersionUID = 1L;

Connection conn=null;
String url="jdbc:mysql://192.168.25.119:3306/";
String dbName="sample?useSSL=false";
String driver="com.mysql.jdbc.Driver";
String dbUserName="neha";
String dbPassword="Neha@123";

/**
 * @see HttpServlet#HttpServlet()
 */
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    

    
    }
	          

/**
 * @param <SimpleDateFormat>
 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub


    	response.setContentType("text/html");  
    	PrintWriter pw = response.getWriter(); 
        try{  
        	
        	String H_id = request.getParameter("val"); 
        	System.out.println("H_id========================="+H_id);
        	String hall_name = request.getParameter("val1");  
            String sitting_capacity = request.getParameter("val2"); 
            boolean projector= Boolean.parseBoolean(request.getParameter("val3"));
        

          Class.forName(driver).newInstance();  
         conn = DriverManager.getConnection(url+dbName,dbUserName, dbPassword);
    
          
       PreparedStatement pst = conn.prepareStatement("update Hall set Hall_name='"+hall_name+"',Sitting_Capacity='"+sitting_capacity+"',projector='"+projector+"'  where H_id="+H_id+" ");  
         
          pst.setString(1,H_id);
          pst.setString(2,hall_name);
          pst.setString(3,sitting_capacity);
          pst.setBoolean(4,projector);
          
          int i = pst.executeUpdate();
         
          String msg=" ";
          if(i!=0){  
            msg="Record has been inserted";
            pw.println("<font size='6' color=blue>" + msg + "</font>");  


          }  
          else{  
            msg="failed to insert the data";
            pw.println("<font size='6' color=blue>" + msg + "</font>");
           }  
          pst.close();
        }  
        catch (Exception e){  
          pw.println(e);  
        }  

    }
}